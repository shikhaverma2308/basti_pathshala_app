
import 'package:flutter/material.dart';
import 'volunteer_form.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('NGO Home')),
      drawer: Drawer(
        child: ListView(
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.blue),
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundImage: AssetImage('assets/logo.png'),
                  ),
                  SizedBox(height: 10),
                  Text('Welcome to Our NGO', style: TextStyle(color: Colors.white)),
                ],
              ),
            ),
            ListTile(
              title: Text('Home'),
              onTap: () => Navigator.pushReplacement(
                context, MaterialPageRoute(builder: (_) => HomePage())),
            ),
            ListTile(
              title: Text('Volunteer Form'),
              onTap: () => Navigator.pushReplacement(
                context, MaterialPageRoute(builder: (_) => VolunteerForm())),
            ),
          ],
        ),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Text(
            'Welcome to Basti Ki Pathshaa Foundation!\n\nWe are a non-profit NGO dedicated to educating and empowering children.\n\nJoin us as a volunteer!',
            style: TextStyle(fontSize: 18),
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
}
